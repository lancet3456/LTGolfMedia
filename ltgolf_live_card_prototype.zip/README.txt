LT Golf Media™ Live Card Prototype

Files:
- index.html      -> digital card page
- reveal.html     -> cinematic reveal step
- landing.html    -> placeholder delivery page
- styles.css      -> styling for all pages

How to use:
1. Upload these files to GitHub Pages, Netlify, or your web host.
2. Point your physical card QR code to index.html.
3. Replace the placeholder text in index.html and landing.html with your client info.
4. Later, swap the QR hotspot link in index.html from reveal.html to any live reveal/landing experience you want.

Fastest launch:
- Put all 4 files in one folder.
- Drag/drop into Netlify or upload to GitHub Pages.
- Use the public URL from index.html in your QR code.

Notes:
- This is built to feel immediate on mobile.
- No external fonts or heavy libraries.
- Black/gold LT Golf Media aesthetic.
